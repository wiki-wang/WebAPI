# 删除课程

from courseFuncs import listCourse
from courseFuncs import deleteCourse
from courseFuncs import addCourse
from datetime import datetime

# 如果系统中没有课程，则先增加一门课程
if listCourse()['total'] == 0:
    cname = "python" + str(datetime.now())
    desc = "python"
    idx = 1

    addCourse(cname, desc, idx)

# 要删除课程，先列出课程，拿到第一个课程id
listC1 = listCourse()
cid = listC1['retlist'][0]['id']

# 删除课程
response = deleteCourse(cid)

# 判断返回码是否正确
assert response['retcode'] == 0

# 判断 返回结果列出的课程 恰好比 删除前 少了删除的课程
listC2 = listCourse()
dCourse = [one for one in listC1['retlist'] if one not in listC2['retlist']]

assert len(dCourse) == 1 and dCourse[0]['id'] == cid