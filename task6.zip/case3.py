# 修改课程

from courseFuncs import modifyCourse
from courseFuncs import listCourse
from datetime import datetime
from courseFuncs import addCourse


# 判断目前是否有课程，如果为空，则添加一门课程
if listCourse()['total'] == 0:
    cname = "python" + str(datetime.now())
    desc = "python"
    idx = 1

    addCourse(cname, desc, idx)

# 要修改课程，先要列出课程，拿到课程的id
retCList = listCourse()

# 取出第一个课程的id
cid = retCList['retlist'][0]['id']

# 课程名字后面加上时间戳，确保名字唯一
cname = retCList['retlist'][0]['name'] + str(datetime.now())

#其它字段不便
desc = retCList['retlist'][0]['desc']
idx = retCList['retlist'][0]['display_idx']

# 修改课程
response = modifyCourse(cid, cname, desc, idx)

# 断言返回码是否正确
assert response['retcode'] == 0

# 查看返回结果是否包含了刚才修改的课程信息
assert {'desc': desc, 'display_idx': idx, 'id': cid, 'name': cname} in listCourse()['retlist']
