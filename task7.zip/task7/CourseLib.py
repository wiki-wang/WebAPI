import requests
import pprint

# 定义列出课程函数
def listCourse():

    response = requests.get('http://localhost/api/mgr/sq_mgr/?action=list_course&pagenum=1&pagesize=20')
    response = response.json()
    pprint.pprint(response)
    return response


# 定义增加课程函数
def addCourse(cname, desc, idx):

    payload = {
        'action': 'add_course',
        'data': '''
        {{  "name": "{}", "desc": "{}", "display_idx": "{}"}}
        '''.format(cname, desc, idx)
    }

    response = requests.post('http://localhost/api/mgr/sq_mgr/', data = payload)
    response = response.json()
    pprint.pprint(response)
    return response


def deleteCourse(cid):
    payload = {
        'action': 'delete_course',
        'id': cid
    }

    response = requests.delete('http://localhost/api/mgr/sq_mgr/', data = payload)
    response = response.json()
    pprint.pprint(response)
    return response

def modifyCourse(cid, name, desc, idx):

    payload = {
        'action': 'modify_course',
        'id': cid,
        'newdata': '''{"name": "%s", "desc": "%s", "display_idx": "%s"}''' % (name, desc, idx)
    }

    response = requests.put('http://localhost/api/mgr/sq_mgr/', data = payload)
    response = response.json()
    pprint.pprint(response)
    return response







