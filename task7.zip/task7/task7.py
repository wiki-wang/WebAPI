'''
步骤：
  1. 使用 工具调用创建课程API来创建1位老师
  2. 代码直接访问数据库的方法，查看系统中数据
预期结果：
  1. 返回创建成功
    {    "retcode": 0 }
  2. 数据库中新增了刚刚创建的老师信息
'''

'''
题目分析:
1.列出课程 获取课程的 id和name
2.调用 增加老师接口，增加一门老师，验证：
    1）返回码正确
    2）查看数据库，数据库中的内容和新增的内容一致
'''


from CourseLib import listCourse
from TeacherLib import addTeacher
from datetime import datetime
import MySQLdb
import json

# 先列出课程
retCourseList = listCourse()
print(retCourseList)


# 获取课程的id和name,存入course列表中
courseList = [{"id":one['id'],"name":one['name']}for one in retCourseList['retlist']]
print(courseList)


username = 'likui' + str(datetime.now())
password = 'sdfsdf'
realname = '李逵' + str(datetime.now())
desc = '李逵老师' + str(datetime.now())
courses = courseList
idx = 1

# 增加老师
ret = addTeacher(username, password, realname, desc, courses, idx)

# 增加成功，返回码应该为0
assert ret['retcode'] == 0, '增加老师失败，返回码不为0'


# 连接MySQL数据库
connection = MySQLdb.connect(host = '66.42.58.17',
                             user = 'root',
                             password = '123456Aa',
                             db = 'plesson',
                             charset = "utf8")

c = connection.cursor()
sql = 'select * from sq_teacher where realname = "{}" and sq_teacher.desc = "{}"'.format(realname,desc)
print(sql)
c.execute(sql)
cOut = c.fetchone()
print(cOut)

# 验证数据库中的查询结果与输入的信息一致
assert cOut[1] == realname and cOut[2] == desc, '老师增加失败'
print('测试通过！')

