import requests
import pprint
import json


# 定义增加老师函数
def addTeacher(username, password, realname, desc, courses, idx):
    data = {
        "username": username,
        "password": password,
        "realname": realname,
        "desc": desc,
        "courses": courses,
        "display_idx": idx
    }
    payload = {
        'action': 'add_teacher',
        'data': json.dumps(data)
    }

    print(payload)

    response = requests.post('http://localhost/api/mgr/sq_mgr/', data = payload)
    response = response.json()
    pprint.pprint(response)
    return response


def deleteTeacher(tid):
    payload = {
        'action': 'delete_teacher',
        'id': tid
    }

    response = requests.delete('http://localhost/api/mgr/sq_mgr/', data = payload)
    response = response.json()
    pprint.pprint(response)
    return response

